---
title: "linux"
permalink: /linux/
#layout: category
layout: posts
author_profile: true
#tags: ['helm']
---
