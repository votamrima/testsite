---
layout: single
title: "Notes for Docker"
subtitle: ""
date: 2023-09-08 08:15:00 +0100
background: '/image/01.jpg'
tags: ['docker']
---

{% raw %}

Here I listed some notes for docker.

**Accessing to container's shell**

````bash
docker exec -it wpdb /bin/bash
````


{% endraw %}