---
layout: single
title: Second element of the CIA Triad - Integrity. Notes
subtitle: ""
date: 2024-08-05 08:15:00 +0100
background: /image/01.jpg
tags:
  - cissp
  - security
---

{% raw %}

Integrity is the concept of protecting the reliability and correctness of the data.

## Reference
- CISSP learning materials

{% endraw %}